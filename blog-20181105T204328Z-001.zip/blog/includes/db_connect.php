<?php

$db = new \MySQLi('localhost','root','', 'blog') or die ('error with connection');
 ?>

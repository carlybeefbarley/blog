<?php
session_start();
if(!isset($_SESSION['user_id'])){
  header('Location: login.php');
  exit();
}
include('../includes/db_connect.php');
//post count
$post_count = $db->query ("SELECT + FROM posts");
//coment count
$comment_count = $db->query ("SELECT + FROM comments");
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset = "utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE-9" />
</head>
<body>
  <div id="container">
    <div id="menu">
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Create New Post</a></li>
        <li><a href="#">Delete Post</a></li>
        <li><a href="#">Log Out</a></li>
        <li><a href="#">Blog Home Page</a></li>
      </ul>
    </div> <!-- end #menu-->
    <div id = "mainContent">
      <table>
        <tr>
          <td>Total Blog Posts</td>
          <td><?php echo $post_count->num_rows?></td>
        </tr>
        <tr>
          <td>Total Comments</td>
          <td><?php echo $comment_count->num_rows?></td>
        </tr>
    </div> <!-- end #mainContent-->
  </div> <!--end #containter-->
<body>
</html>

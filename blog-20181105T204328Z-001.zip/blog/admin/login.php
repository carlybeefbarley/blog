<?php
if(isset($_POST['submit'])){
  $user = $_POST['username'];
  $pwrd = $_POST['pwrd'];
  //include database
  include('../includes/db_connect.php');
  if(empty($user) || empty($pwrd)){
    echo 'Missing Information';
  }else{
    $user = strip_tags($user);
    $user = $db -> real_escape_string($pwrd);
    $pwrd = strip_tags($user);
    $pwrd = $db->real_escape_string($pwrd);
    $pwrd = md5($pwrd);
    $query = $db->query("SELECT user_id, username FROM user WHERE username='$user' AND password='$pwrd'");
    echo $query->num_rows;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset = "utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE-9" />
  <script language="javaScript" type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
</head>
<body>
  <div id = "container">
    <form action="login.php" method="post">
      <p>
        <label>Username</label><input type="text" name="username" />
      </p>
      <p>
        <label>Password</label><input type="password" name="pword" />
      </p>
      <input type="submit" name="submit" value="LogIn" />
    </form>
  </div> <!--end #container-->
</body>
</html>
